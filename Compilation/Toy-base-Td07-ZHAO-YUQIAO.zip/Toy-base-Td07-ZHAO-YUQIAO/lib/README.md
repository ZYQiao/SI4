# README  for the lib directory

This directory contains C utilities:

  * `list.c`: a generic list module
  * `hash.c`: a generic hash table implementation 

The code is dead simple and no provision was made to optimize it. 

------ 
Erick Gallesio
