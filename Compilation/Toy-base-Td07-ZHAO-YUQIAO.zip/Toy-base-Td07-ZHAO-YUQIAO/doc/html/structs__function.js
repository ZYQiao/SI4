var structs__function =
[
    [ "body", "structs__function.html#a2f4e7dcd701e3de526e64a1fff558858", null ],
    [ "header", "structs__function.html#aa254fe4d1fefc68bf19e6ff81d7656cc", null ],
    [ "name", "structs__function.html#a078a87b785128246e48ca1dc1ab49190", null ],
    [ "parameters", "structs__function.html#aeafb87ff3c2b5f0847093d6e39e02ad8", null ]
];