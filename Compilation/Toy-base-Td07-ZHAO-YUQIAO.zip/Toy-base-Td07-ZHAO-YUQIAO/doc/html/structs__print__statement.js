var structs__print__statement =
[
    [ "header", "structs__print__statement.html#aa254fe4d1fefc68bf19e6ff81d7656cc", null ],
    [ "parameters", "structs__print__statement.html#aeafb87ff3c2b5f0847093d6e39e02ad8", null ]
];