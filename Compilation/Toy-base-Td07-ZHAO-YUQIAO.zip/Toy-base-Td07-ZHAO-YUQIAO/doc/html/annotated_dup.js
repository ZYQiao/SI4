var annotated_dup =
[
    [ "ast_node", "structast__node.html", "structast__node" ],
    [ "elt", "structelt.html", "structelt" ],
    [ "hash_table", "structhash__table.html", "structhash__table" ],
    [ "s_block_statement", "structs__block__statement.html", "structs__block__statement" ],
    [ "s_call", "structs__call.html", "structs__call" ],
    [ "s_constant", "structs__constant.html", "structs__constant" ],
    [ "s_expr_statement", "structs__expr__statement.html", "structs__expr__statement" ],
    [ "s_expression", "structs__expression.html", "structs__expression" ],
    [ "s_function", "structs__function.html", "structs__function" ],
    [ "s_identifier", "structs__identifier.html", "structs__identifier" ],
    [ "s_if_statement", "structs__if__statement.html", "structs__if__statement" ],
    [ "s_list", "structs__list.html", "structs__list" ],
    [ "s_list_item", "structs__list__item.html", "structs__list__item" ],
    [ "s_print_statement", "structs__print__statement.html", "structs__print__statement" ],
    [ "s_return_statement", "structs__return__statement.html", "structs__return__statement" ],
    [ "s_type", "structs__type.html", "structs__type" ],
    [ "s_var_decl", "structs__var__decl.html", "structs__var__decl" ],
    [ "s_while_statement", "structs__while__statement.html", "structs__while__statement" ],
    [ "symbol_table", "structsymbol__table.html", "structsymbol__table" ]
];