var searchData=
[
  ['init_5fast',['init_ast',['../ast_8c.html#af55b8bf8468f4e4ed7cecb1de50fd4ed',1,'init_ast(void):&#160;ast.c'],['../ast_8h.html#af55b8bf8468f4e4ed7cecb1de50fd4ed',1,'init_ast(void):&#160;ast.c']]],
  ['init_5fsymbols',['init_symbols',['../symbols_8c.html#a6a48afec40cbfecd5a959ad94dece194',1,'init_symbols(void):&#160;symbols.c'],['../symbols_8h.html#a6a48afec40cbfecd5a959ad94dece194',1,'init_symbols(void):&#160;symbols.c']]]
];
