var searchData=
[
  ['ident_5fval',['IDENT_VAL',['../ast_8h.html#a7b29cf8981fc18ccd26b12e89749899d',1,'ast.h']]],
  ['initial_5fsize',['INITIAL_SIZE',['../hash_8c.html#a40958a1382463445e451148e3a93e049',1,'hash.c']]]
];
