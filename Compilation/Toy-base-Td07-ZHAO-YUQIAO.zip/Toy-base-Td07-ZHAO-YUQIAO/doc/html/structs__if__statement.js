var structs__if__statement =
[
    [ "cond", "structs__if__statement.html#a8f30b6c9b68c5babfc17109357fc6c19", null ],
    [ "else_stat", "structs__if__statement.html#a1c422dcd05b9943cf9940d37abee6335", null ],
    [ "header", "structs__if__statement.html#aa254fe4d1fefc68bf19e6ff81d7656cc", null ],
    [ "then_stat", "structs__if__statement.html#ad302af6d65b98650ce603807a2ea64ba", null ]
];