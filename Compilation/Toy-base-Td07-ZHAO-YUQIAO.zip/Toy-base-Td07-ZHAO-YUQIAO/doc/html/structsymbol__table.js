var structsymbol__table =
[
    [ "next", "structsymbol__table.html#aa7d0fca0cddf053575bc3bd138e51320", null ],
    [ "table", "structsymbol__table.html#ab61feff1c6047222b65d5bd51d837c79", null ]
];