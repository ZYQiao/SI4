var structs__list =
[
    [ "first", "structs__list.html#a5fd30c1efc8eddf2beed395c4ba650b4", null ],
    [ "last", "structs__list.html#a518f6f37135ab75e75b6f6a5b46a5a08", null ],
    [ "size", "structs__list.html#a439227feff9d7f55384e8780cfc2eb82", null ]
];