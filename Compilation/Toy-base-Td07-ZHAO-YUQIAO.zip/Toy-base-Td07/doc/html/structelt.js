var structelt =
[
    [ "free", "structelt.html#a00cac9e5111cbc007e391e5017fa5af5", null ],
    [ "key", "structelt.html#a5892a9181e6a332f84d27aecd41dcd12", null ],
    [ "next", "structelt.html#a054bea2012edef97a279278839adad15", null ],
    [ "value", "structelt.html#a0f61d63b009d0880a89c843bd50d8d76", null ]
];