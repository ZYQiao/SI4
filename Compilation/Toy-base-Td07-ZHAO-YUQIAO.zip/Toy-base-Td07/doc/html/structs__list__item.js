var structs__list__item =
[
    [ "data", "structs__list__item.html#a735984d41155bc1032e09bece8f8d66d", null ],
    [ "free", "structs__list__item.html#a00cac9e5111cbc007e391e5017fa5af5", null ],
    [ "next", "structs__list__item.html#afbcfb31ac627aea1a43a2c0039593007", null ]
];