var searchData=
[
  ['table',['table',['../structsymbol__table.html#ab61feff1c6047222b65d5bd51d837c79',1,'symbol_table::table()'],['../structhash__table.html#a762183d8f58832cf65e8ad9506b98efb',1,'hash_table::table()']]],
  ['then_5fstat',['then_stat',['../structs__if__statement.html#ad302af6d65b98650ce603807a2ea64ba',1,'s_if_statement']]],
  ['type',['type',['../structast__node.html#aefb0f1c0ed419ceb923d1a64496dbcf1',1,'ast_node']]]
];
