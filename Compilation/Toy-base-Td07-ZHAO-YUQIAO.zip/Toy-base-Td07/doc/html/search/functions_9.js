var searchData=
[
  ['symbol_5ftable_5fdeclare_5fobject',['symbol_table_declare_object',['../symbols_8c.html#a30808b77179c53ea57c55a360f4a8191',1,'symbol_table_declare_object(char *id, ast_node *obj):&#160;symbols.c'],['../symbols_8h.html#a3550d7d5521117ab21092d1ac9bc0186',1,'symbol_table_declare_object(char *id, ast_node *ident):&#160;symbols.c']]],
  ['symbol_5ftable_5ffree_5funused_5ftables',['symbol_table_free_unused_tables',['../symbols_8c.html#adeac0cb33d80a10b645734c7c580dd03',1,'symbol_table_free_unused_tables(void):&#160;symbols.c'],['../symbols_8h.html#adeac0cb33d80a10b645734c7c580dd03',1,'symbol_table_free_unused_tables(void):&#160;symbols.c']]],
  ['symbol_5ftable_5freplace_5fprototype',['symbol_table_replace_prototype',['../symbols_8c.html#ad7c912ac18cee1bdd05e10f248b7f438',1,'symbol_table_replace_prototype(char *id, ast_node *func):&#160;symbols.c'],['../symbols_8h.html#ad7c912ac18cee1bdd05e10f248b7f438',1,'symbol_table_replace_prototype(char *id, ast_node *func):&#160;symbols.c']]],
  ['symbol_5ftable_5fsearch',['symbol_table_search',['../symbols_8c.html#af7e9ece683f29c963bfa861dd42136d4',1,'symbol_table_search(char *id):&#160;symbols.c'],['../symbols_8h.html#af7e9ece683f29c963bfa861dd42136d4',1,'symbol_table_search(char *id):&#160;symbols.c']]],
  ['symbol_5ftable_5fsearch_5fprototype',['symbol_table_search_prototype',['../symbols_8c.html#a376304b7cfd19dc56821088e85d969dc',1,'symbol_table_search_prototype(char *id):&#160;symbols.c'],['../symbols_8h.html#a376304b7cfd19dc56821088e85d969dc',1,'symbol_table_search_prototype(char *id):&#160;symbols.c']]]
];
