var toy_runtime_8c =
[
    [ "_toy_print_bool", "toy-runtime_8c.html#afeec48f3ae57866893179067a055f3c7", null ],
    [ "_toy_print_int", "toy-runtime_8c.html#a3caa3f94b75de63d3b5dc956cba19413", null ],
    [ "_toy_print_string", "toy-runtime_8c.html#a84a6939ae3a550d105e10486d43f01fa", null ]
];