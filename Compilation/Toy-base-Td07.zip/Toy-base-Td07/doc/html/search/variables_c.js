var searchData=
[
  ['parameters',['parameters',['../structs__function.html#aeafb87ff3c2b5f0847093d6e39e02ad8',1,'s_function::parameters()'],['../structs__call.html#aeafb87ff3c2b5f0847093d6e39e02ad8',1,'s_call::parameters()'],['../structs__print__statement.html#aeafb87ff3c2b5f0847093d6e39e02ad8',1,'s_print_statement::parameters()']]],
  ['produce_5fcode',['produce_code',['../structast__node.html#af8b6b188c54b9dc7fb3655dfef5f1e1b',1,'ast_node']]],
  ['progname',['progname',['../main_8c.html#ab9e1449fd00c98428516f0b41eddcb10',1,'progname():&#160;main.c'],['../toy_8h.html#ab9e1449fd00c98428516f0b41eddcb10',1,'progname():&#160;main.c']]]
];
