var structs__call =
[
    [ "callee", "structs__call.html#a1e47fdf46d402eeeca8ad52a3515acd4", null ],
    [ "header", "structs__call.html#aa254fe4d1fefc68bf19e6ff81d7656cc", null ],
    [ "parameters", "structs__call.html#aeafb87ff3c2b5f0847093d6e39e02ad8", null ]
];