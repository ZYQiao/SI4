var toy_8h =
[
    [ "TOY_VERSION", "toy_8h.html#a4c5cc9b8aad94782d5cdb9a2716a47c6", null ],
    [ "fout", "toy_8h.html#acec19516a59050bb447192fe318e6a9c", null ],
    [ "input_path", "toy_8h.html#ae034085e87d427c78144ccce961ee56f", null ],
    [ "output_path", "toy_8h.html#a73c330e3842fe255aa5e7d82bf573289", null ],
    [ "progname", "toy_8h.html#ab9e1449fd00c98428516f0b41eddcb10", null ]
];