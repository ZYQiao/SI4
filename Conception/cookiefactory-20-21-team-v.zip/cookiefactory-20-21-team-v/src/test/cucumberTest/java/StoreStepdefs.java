package cucumberTest.java;

public class StoreStepdefs {
}
