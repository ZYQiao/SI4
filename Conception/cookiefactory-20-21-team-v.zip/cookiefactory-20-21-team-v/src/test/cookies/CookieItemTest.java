package cookies;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class CookieItemTest {

    @Test
    void getPrice() {
    }

    @Test
    void getQuantity() {
    }

    @Test
    void getRecipeName() {
    }

    @Test
    void setPrice() {
    }

    @Test
    void setQuantity() {
    }

    @Test
    void setRecipeName() {
    }
}