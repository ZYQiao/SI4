package cookies.manager;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class StoreManagerTest {

    @Test
    void getTax() {
    }

    @Test
    void setTax() {
    }

    @Test
    void getDay() {
    }

    @Test
    void getOpenHour() {
    }

    @Test
    void setOpenHour() {
    }
}