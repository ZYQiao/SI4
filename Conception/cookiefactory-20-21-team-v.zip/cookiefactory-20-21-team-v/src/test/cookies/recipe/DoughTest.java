package cookies.recipe;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class DoughTest {

    @Test
    void setType() {
    }

    @Test
    void getType() {
    }
}