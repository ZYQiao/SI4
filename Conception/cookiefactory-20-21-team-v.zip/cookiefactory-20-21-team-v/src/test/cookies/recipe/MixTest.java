package cookies.recipe;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class MixTest {

    @Test
    void getType() {
    }

    @Test
    void setType() {
    }
}