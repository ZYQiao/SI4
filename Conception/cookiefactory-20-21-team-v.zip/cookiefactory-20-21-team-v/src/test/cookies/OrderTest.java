package cookies;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class OrderTest {

    @Test
    void addCookieItem() {
    }

    @Test
    void caculatePrice() {
    }

    @Test
    void caculateDiscountPrice() {
    }

    @Test
    void setPickUpDate() {
    }

    @Test
    void setPickUpStore() {
    }
}