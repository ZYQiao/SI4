package cookies;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class CookieFactoryTest {

    @Test
    void resetFactory() {
    }

    @Test
    void getRecipesList() {
    }

    @Test
    void getRecipe() {
    }

    @Test
    void getStore() {
    }

    @Test
    void addRecipe() {
    }

    @Test
    void deleteRecipe() {
    }

    @Test
    void addStore() {
    }

    @Test
    void deleteStore() {
    }

    @Test
    void getStoreList() {
    }
}