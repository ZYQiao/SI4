package cookies.recipe;

public class Dough {
    private String type;

    public Dough(String type){
        this.type = type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getType() {
        return type;
    }
}
