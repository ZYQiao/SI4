package cookies.recipe;

public class Flavour {
    private String type;

    public Flavour(String type){
        this.type = type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getType() {
        return type;
    }
}
